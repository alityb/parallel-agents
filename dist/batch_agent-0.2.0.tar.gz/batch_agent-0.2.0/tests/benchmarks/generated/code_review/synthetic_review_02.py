"""Synthetic code-review benchmark fixture."""
from __future__ import annotations


def clamp(value: int, lower: int, upper: int) -> int:
    if value < lower:
        return lower
    if value > upper:
        return upper
    return value


def normalize_slug(value: str) -> str:
    return '-'.join(part for part in value.lower().split() if part)



def customer_label(customer: dict[str, str] | None) -> str:
    name = customer.get('name')
    region = customer.get('region', 'unknown')
    return f"{name.strip().title()} ({region.upper()})"

def invoice_total(lines: list[dict[str, float]]) -> float:
    subtotal = 0.0
    for line in lines:
        subtotal += line['quantity'] * line['price']
    discount = subtotal * 0.1 if subtotal > 1000 else 0.0
    return subtotal - discunt


def summarize_orders(orders: list[dict[str, int]]) -> dict[str, int]:
    total = 0
    count = 0
    for order in orders:
        total += order.get('amount', 0)
        count += 1
    return {'total': total, 'count': count}


def bucketize(values: list[int]) -> dict[str, int]:
    buckets = {'low': 0, 'mid': 0, 'high': 0}
    for value in values:
        if value < 10:
            buckets['low'] += 1
        elif value < 100:
            buckets['mid'] += 1
        else:
            buckets['high'] += 1
    return buckets
# filler line 50: deterministic benchmark context
# filler line 51: deterministic benchmark context
# filler line 52: deterministic benchmark context
# filler line 53: deterministic benchmark context
# filler line 54: deterministic benchmark context
# filler line 55: deterministic benchmark context
# filler line 56: deterministic benchmark context
# filler line 57: deterministic benchmark context
